import { Component, OnInit } from '@angular/core';
import { Table_columns } from './Table_columns'

@Component({
  selector: 'app-hvr-table',
  templateUrl: './hvr-table.component.html',
  styleUrls: ['./hvr-table.component.css']
})

export class HvrTableComponent implements OnInit {

  columns:Table_columns[];
  constructor() { }

  ngOnInit() {
    this.columns=[
      {
        System_Name:'Eservice',
        Job_Name:'esc_cap',
        Status:'RUNNING',
        Last_Start_time:'01:04',
        Last_End_time:'01:04',
        No_of_Retries:'3',
        Log:'location'
        },
      {
        System_Name:'Eservice',
        Job_Name:'esc_integ',
        Status:'SUSPEND',
        Last_Start_time:'01:04',
        Last_End_time:'01:04',
        No_of_Retries:'3',
        Log:'location'
        },
        {
        System_Name:'Eservice',
        Job_Name:'esc_ref',
        Status:'PENDING',
        Last_Start_time:'01:04',
        Last_End_time:'01:04',
        No_of_Retries:'3',
        Log:'location'
        }
      ];
    }
    
}
