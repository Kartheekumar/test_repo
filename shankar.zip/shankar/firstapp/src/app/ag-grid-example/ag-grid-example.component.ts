import { Component } from '@angular/core';

@Component({
  selector: 'app-ag-grid-example',
  templateUrl: './ag-grid-example.component.html',
  styleUrls: ['./ag-grid-example.component.css']
})
export class AgGridExampleComponent {

  title = 'app';

    columnDefs = [
        {headerName: 'System_Name', field: 'System_Name',sortable: true,filter: true },
        {headerName: 'Job_Name', field: 'Job_Name',sortable: true,filter: true },
        {headerName: 'Status', field: 'Status',sortable: true,filter: true},
        {headerName: 'Last_Start_time', field: 'Last_Start_time',sortable: true,filter: true},
        {headerName: 'Last_End_time', field: 'Last_End_time',sortable: true,filter: true},
        {headerName: 'No_of_Retries', field: 'No_of_Retries',sortable: true,filter: true},
        {headerName: 'Log', field: 'Log'}

    ];

    rowData = [
      {
        System_Name:'Eservice',
        Job_Name:'esc_cap',
        Status:'RUNNING',
        Last_Start_time:'01:04',
        Last_End_time:'01:04',
        No_of_Retries:'3',
        Log:'location'
        },
      {
        System_Name:'Eservice',
        Job_Name:'esc_integ',
        Status:'SUSPEND',
        Last_Start_time:'01:04',
        Last_End_time:'01:04',
        No_of_Retries:'3',
        Log:'location'
        },
        {
        System_Name:'Eservice',
        Job_Name:'esc_ref',
        Status:'PENDING',
        Last_Start_time:'01:04',
        Last_End_time:'01:04',
        No_of_Retries:'3',
        Log:'location'
        }
      ];

}
