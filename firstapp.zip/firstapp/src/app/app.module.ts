import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SchedulerComponent } from './scheduler/scheduler.component';
import { HvrTableComponent } from './hvr-table/hvr-table.component';
import { TableBasicExampleComponent } from './table-basic-example/table-basic-example.component';


@NgModule({
  declarations: [
    AppComponent,
    SchedulerComponent,
    HvrTableComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent,SchedulerComponent,HvrTableComponent]
})
export class AppModule { }
