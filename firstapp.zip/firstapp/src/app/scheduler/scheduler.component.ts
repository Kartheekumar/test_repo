import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scheduler',
  templateUrl: './scheduler.component.html',
  styleUrls: ['./scheduler.component.css']
})
export class SchedulerComponent implements OnInit {

  scheduler_status:string;
  constructor() {
    this.scheduler_status=this.get_scheduler_status();
   }

  ngOnInit() {
  }
  get_scheduler_status():string{
    return 'Active';
}
getColor() {  
  return this.scheduler_status.toUpperCase() == 'Active'.toUpperCase() ? 'green' : 'red';  
}  
}
